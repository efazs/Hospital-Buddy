package com.example.efas.hospital_buddy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ambulance_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ambulance_list);
    }
}
