package com.example.efas.hospital_buddy;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.Map;

public class hospital_details extends AppCompatActivity {



    Firebase name;
    String link="https://hospital-buddy.firebaseio.com/Hospital";

    String s="";
    String _Name="";
    String _Price="";
    String _contact="";
    String _Location="";
    String _specialty="";
    String _details="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_details);
        final TextView tv2 =(TextView) findViewById(R.id.textView2);
        final TextView tv3 =(TextView) findViewById(R.id.htextView3);
        final TextView tv4 =(TextView) findViewById(R.id.htextView4);
        final TextView tv5 =(TextView) findViewById(R.id.htextView5);
        final TextView tv6 =(TextView) findViewById(R.id.htextView6);
        final TextView tv7 =(TextView) findViewById(R.id.htextView7);
        final Button button2=(Button) findViewById(R.id.button_map);
        final Button button=(Button) findViewById(R.id.button_edit_hospital);
        s=getIntent().getStringExtra("Type");
        int admin=getIntent().getIntExtra("admin",0);
        if(admin==1)
        {
            button.setVisibility(View.VISIBLE);
        }
        tv2.setText(s);
        link=link+"/"+s;

        name = new Firebase(link);


        name.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Map<String,String> map=dataSnapshot.getValue(Map.class);
                _Name=map.get("Name");
                _Price=map.get("Price_Range");
                _contact=map.get("Contact");
                _Location=map.get("Location");
                _specialty=map.get("Specialty");
                _details=map.get("Details");

                tv3.setText(_Location);
                tv4.setText(_contact);
                tv5.setText(_Price);
                tv6.setText(_specialty);
                tv7.setText(_details);


            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(hospital_details.this,adminhospital.class);
                intent.putExtra("Key",s);
                intent.putExtra("Name",_Name);
                intent.putExtra("Location",_Location);
                intent.putExtra("Contact",_contact);
                intent.putExtra("Price",_Price);
                intent.putExtra("Specialty",_specialty);
                intent.putExtra("Details",_details);

                intent.putExtra("Edit",1);
                startActivity(intent);

            }
        });


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse("geo:23.455980,91.181931?="+Uri.encode(_Name)));
                Intent chooser=Intent.createChooser(i,"Launch Maps");
                startActivity(chooser);
            }
        });


    }
}
