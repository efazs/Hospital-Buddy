package com.example.efas.hospital_buddy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.firebase.client.Firebase;

public class admin_donor extends AppCompatActivity {


    String key="";
    String dname="";
    String dbloodgroup="";
    String dcontact="";
    Firebase firebase;


    EditText tv2;
    EditText tv3;
    EditText tv4;

    Button button;
    int asd=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_donor);


        tv2 =(EditText) findViewById(R.id.textViewnamed);
        tv3 =(EditText) findViewById(R.id.textViewBloodd);
        tv4 =(EditText) findViewById(R.id.textViewcontactd);

        button=(Button) findViewById(R.id.button_edit_donor2);
        asd=getIntent().getIntExtra("Edit",0);
        if(asd==1)
        {
            key=getIntent().getStringExtra("Key");
            dname= getIntent().getStringExtra("Name");
            dbloodgroup=getIntent().getStringExtra("bloodgroup");
            dcontact=getIntent().getStringExtra("Contact");

            // tv2.setEnabled(false);
            tv2.setText(dname);
            tv3.setText(dbloodgroup);
            tv4.setText(dcontact);


        }


        firebase=new Firebase("https://hospital-buddy.firebaseio.com/Doner");

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stringn=tv2.getText().toString();
                //String keyval=stringn.replace(" ","_");
                String stringnl=tv3.getText().toString();
                String stringnc=tv4.getText().toString();

                if(asd!=1)
                {
                    key=stringn;
                }


                Firebase child1=firebase.child(key);
                Firebase childn=child1.child("Name");
                Firebase childl=child1.child("Blood Group");
                Firebase childc=child1.child("Contact");

                childn.setValue(stringn);
                childl.setValue(stringnl);
                childc.setValue(stringnc);



                admin_donor.this.finish();
            }
        });



    }
}
