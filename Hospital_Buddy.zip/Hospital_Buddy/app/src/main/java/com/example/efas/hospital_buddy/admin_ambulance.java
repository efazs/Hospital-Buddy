package com.example.efas.hospital_buddy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.firebase.client.Firebase;

public class admin_ambulance extends AppCompatActivity {

    String key="";
    String aname="";
    String acnumber="";
    String acontact="";
    Firebase firebase;


    EditText tv2;
    EditText tv3;
    EditText tv4;
    int asd=0;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_ambulance);

        tv2 =(EditText) findViewById(R.id.textViewnamea);
        tv3 =(EditText) findViewById(R.id.textViewCarnumbera);
        tv4 =(EditText) findViewById(R.id.textViewcontacta);

        button=(Button) findViewById(R.id.button_edit_ambulance2);
        asd=getIntent().getIntExtra("Edit",0);
        if(asd==1)
        {
            key=getIntent().getStringExtra("Key");
            aname= getIntent().getStringExtra("Name");
            acnumber=getIntent().getStringExtra("Car");
            acontact=getIntent().getStringExtra("Contact");

            // tv2.setEnabled(false);
            tv2.setText(aname);
            tv3.setText(acnumber);
            tv4.setText(acontact);


        }

        firebase=new Firebase("https://hospital-buddy.firebaseio.com/Ambulance");

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stringn=tv2.getText().toString();
                //String keyval=stringn.replace(" ","_");
                String stringnl=tv3.getText().toString();
                String stringnc=tv4.getText().toString();



                if(asd!=1)
                {
                    key=stringn;
                }
                Firebase child1=firebase.child(key);
                Firebase childn=child1.child("name");
                Firebase childl=child1.child("Car Number");
                Firebase childc=child1.child("Contact");


                childn.setValue(stringn);
                childl.setValue(stringnl);
                childc.setValue(stringnc);



                admin_ambulance.this.finish();
            }
        });

    }
}
