package com.example.efas.hospital_buddy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Admin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        final Button views=(Button) findViewById(R.id.button_view);
        final Button add=(Button) findViewById(R.id.button_add);
        final Button add_hospital=(Button) findViewById(R.id.button_hospital);
        final Button add_ambulance=(Button) findViewById(R.id.button_ambulance);
        final Button add_doner=(Button) findViewById(R.id.button_blood);

        views.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Admin.this,MainActivity.class);
                intent.putExtra("AdminPrevilage",1);
                startActivity(intent);
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add_hospital.setVisibility(View.VISIBLE);
                add_ambulance.setVisibility(View.VISIBLE);
                add_doner.setVisibility(View.VISIBLE);
            }
        });

        add_ambulance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Admin.this,admin_ambulance.class);
                startActivity(i);
            }
        });
        add_doner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Admin.this,admin_donor.class);
                startActivity(i);
            }
        });
        add_hospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Admin.this,adminhospital.class);
                startActivity(i);
            }
        });
    }
}
