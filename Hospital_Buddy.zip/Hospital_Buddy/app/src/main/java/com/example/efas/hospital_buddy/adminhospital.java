package com.example.efas.hospital_buddy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.firebase.client.Firebase;

public class adminhospital extends AppCompatActivity {

    String key="";
    String hname="";
    String hlocation="";
    String hcontact="";
    String hprice="";
    String hspecialty="";
    String hdetails="";

    Firebase firebase;


    EditText tv2;
    EditText tv3;
    EditText tv4;
    EditText tv5;
    EditText tv6;
    EditText tv7;
    Button button;

    int asd=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminhospital);


        tv2 =(EditText) findViewById(R.id.textViewname);
        tv3 =(EditText) findViewById(R.id.textViewlocation);
        tv4 =(EditText) findViewById(R.id.textViewcontact);
        tv5 =(EditText) findViewById(R.id.textViewprice);
        tv6 =(EditText) findViewById(R.id.textViewspecialty);
        tv7 =(EditText) findViewById(R.id.textViewdetails);
        button=(Button) findViewById(R.id.button_edit_hospital2);


        asd=getIntent().getIntExtra("Edit",0);
        if(asd==1)
        {
            key=getIntent().getStringExtra("Key");
            hname= getIntent().getStringExtra("Name");
            hlocation=getIntent().getStringExtra("Location");
            hcontact=getIntent().getStringExtra("Contact");
            hprice=getIntent().getStringExtra("Price");
            hspecialty=getIntent().getStringExtra("Specialty");
            hspecialty=getIntent().getStringExtra("Details");

            // tv2.setEnabled(false);
            tv2.setText(hname);
            tv3.setText(hlocation);
            tv4.setText(hcontact);
            tv5.setText(hprice);
            tv6.setText(hspecialty);
            tv7.setText(hdetails);


        }
        //String link="https://hospital-buddy.firebaseio.com/Hospital";
        //link=link+key;
        firebase=new Firebase("https://hospital-buddy.firebaseio.com/Hospital");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stringn=tv2.getText().toString();
                //String keyval=stringn.replace(" ","_");
                String stringnl=tv3.getText().toString();
                String stringnc=tv4.getText().toString();
                String stringnp=tv5.getText().toString();
                String stringns=tv6.getText().toString();
                String stringnd=tv7.getText().toString();


                if(asd!=1)
                {
                    key=stringn;
                }

                Firebase child1=firebase.child(key);
                Firebase childn=child1.child("Name");
                Firebase childl=child1.child("Location");
                Firebase childc=child1.child("Contact");
                Firebase childp=child1.child("Price_Range");
                Firebase childs=child1.child("Specialty");
                Firebase childd=child1.child("Details");


                childn.setValue(stringn);
                childl.setValue(stringnl);
                childc.setValue(stringnc);
                childp.setValue(stringnp);
                childs.setValue(stringns);
                childd.setValue(stringnd);



                adminhospital.this.finish();

            }
        });


    }
}
