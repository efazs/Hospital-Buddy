package com.example.efas.hospital_buddy;

import android.app.Application;

import com.firebase.client.Firebase;

public class Hospital_Buddy extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Firebase.setAndroidContext(this);
    }
}
