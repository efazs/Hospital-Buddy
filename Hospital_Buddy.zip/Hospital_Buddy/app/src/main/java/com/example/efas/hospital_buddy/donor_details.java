package com.example.efas.hospital_buddy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.Map;

public class donor_details extends AppCompatActivity {

    Firebase name;
    String link="https://hospital-buddy.firebaseio.com/Doner";

    String s="";
    String _dName="";
    String _dcontact="";
    String _dbloodgroup="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor_details);

        final TextView tv2 =(TextView) findViewById(R.id.dtextView2);
        final TextView tv3 =(TextView) findViewById(R.id.dtextView3);
        final TextView tv4 =(TextView) findViewById(R.id.dtextView4);

        final Button button=(Button) findViewById(R.id.button_edit_donor);


        s=getIntent().getStringExtra("Type");
        int admin=getIntent().getIntExtra("admin",0);
        if(admin==1)
        {
            button.setVisibility(View.VISIBLE);
        }
        tv2.setText(s);
        link=link+"/"+s;

        name = new Firebase(link);

        name.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Map<String,String> map=dataSnapshot.getValue(Map.class);
                _dName=map.get("Name");

                _dcontact=map.get("Contact");

                _dbloodgroup=map.get("Blood Group");

                tv3.setText(_dbloodgroup);
                tv4.setText(_dcontact);

            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(donor_details.this,admin_donor.class);
                intent.putExtra("Key",s);
                intent.putExtra("Name",_dName);
                intent.putExtra("bloodgroup",_dbloodgroup);
                intent.putExtra("Contact",_dcontact);
                intent.putExtra("Edit",1);
                startActivity(intent);
            }
        });



    }
}
